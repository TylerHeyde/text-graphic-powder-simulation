#include "frameWork.h"
///------------------------------------------------------------------------------------------------------
/// controls:     WASD: move the spawner - Space: spawn powder - Q: advance frames - R: clear powder
///------------------------------------------------------------------------------------------------------


int main() {


    enum ELEMENTS {SAND, WATER, WALL};
    int currentElement = SAND;

    int x = 0;
    int y = 1;
    char c = 0;


    char elementArray [HEIGHT][WIDTH];
    fillBoard(elementArray, HEIGHT, WIDTH);


    hideCursor();
    putStringAt(5,0, "Use w a s d to move| sand-1 water-2 wall-3", Color::Yellow);
    putStringAt(48,0, "Current Element: ", Color::Red);
    if (currentElement == SAND){
        putStringAt(65,0, "Sand ('*')", Color::BrightYellow);
    }
    else if (currentElement == WATER){
        putStringAt(65,0, "Water ('~')", Color::BrightYellow);
    }
    else if (currentElement == WALL){
        putStringAt(65,0, "Wall ('#')", Color::BrightYellow);
    }
    printBoard(elementArray, HEIGHT, WIDTH);

    while(c != ESCAPE)
    {
        //updateBoard(elementArray, HEIGHT, WIDTH);
        putCharAt(x,y, SQUARE, Color::Red);
        c = readKey();
        if(c != -1)
        {
            clearScreen();
            putStringAt(5,0, "Use w a s d to move| sand-1 water-2 wall-3", Color::Yellow);
            putStringAt(48,0, "Current Element: ", Color::Red);
            if (currentElement == SAND){
                putStringAt(65,0, "Sand ('*')", Color::BrightYellow);
            }
            else if (currentElement == WATER){
                putStringAt(65,0, "Water ('~')", Color::BrightBlue);
            }
            else if (currentElement == WALL){
                putStringAt(65,0, "Wall ('#')", Color::BrightBlack);
            }
            printBoard(elementArray, HEIGHT, WIDTH);

            if(c == 'w' && y > 1)
            {
                y--;
            }
            else if(c == 's' && y < HEIGHT)
            {
                y++;
            }
            else if(c == 'a' && x > 0)
            {
                x--;
            }
            else if(c == 'd' && x < WIDTH - 1)
            {
                x++;
            }
            else if(c == '1'){
                if (currentElement != SAND){
                    currentElement = SAND;
                }
            }
            else if(c == '2'){
                if (currentElement != WATER){
                    currentElement = WATER;
                }
            }
            else if(c == '3'){
                if (currentElement != WALL){
                    currentElement = WALL;
                }
            }
            else if(c == ' '){
                if (currentElement == SAND){
                    elementArray [y-1][x] = '*';
                }
                else if (currentElement == WATER){
                    elementArray [y-1][x] = '~';
                }
                else if (currentElement == WALL){
                    elementArray [y-1][x] = '#';

                }
            }
            else if(c == 'q'){
                updateBoard(elementArray, HEIGHT, WIDTH);
            }
            else if(c == 'r'){
                fillBoard(elementArray, HEIGHT, WIDTH);
            }

        }
    }

    return 0;
}
