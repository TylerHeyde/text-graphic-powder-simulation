#include "frameWork.h"

int main() {


    enum ELEMENTS {SAND, WATER, WALL, AIR};
    int currentElement = SAND;

    int x = 0;
    int y = 1;
    char c = 0;


    char elementArray [HEIGHT][WIDTH];
    fillBoard(elementArray, HEIGHT, WIDTH);


    hideCursor();
    putStringAt(2,0, "WASD to move| sand-1 water-2 wall-3 air-4| Space: place | Q: next frame | R: reset | ",Color::Yellow);
    putStringAt(87,0, "Current Element: ", Color::Red);
    if (currentElement == SAND){
        putStringAt(104,0, "Sand ('*')", Color::BrightYellow);
    }
    else if (currentElement == WATER){
        putStringAt(104,0, "Water ('~')", Color::BrightBlue);
    }
    else if (currentElement == WALL){
        putStringAt(104,0, "Wall ('#')", Color::BrightBlack);
    }
    else if (currentElement == AIR){
        putStringAt(104,0, "Air (' ')", Color::Magenta);
    }
    printBoard(elementArray, HEIGHT, WIDTH);

    while(c != ESCAPE)
    {
        //updateBoard(elementArray, HEIGHT, WIDTH);
        putCharAt(x,y, SQUARE, Color::Red);
        c = readKey();
        if(c != -1)
        {
            clearScreen();
            putStringAt(2,0, "WASD to move| sand-1 water-2 wall-3 air-4| Space: place | Q: next frame | R: reset | ",Color::Yellow);
            putStringAt(87,0, "Current Element: ", Color::Red);
            if (currentElement == SAND){
                putStringAt(104,0, "Sand ('*')", Color::BrightYellow);
            }
            else if (currentElement == WATER){
                putStringAt(104,0, "Water ('~')", Color::BrightBlue);
            }
            else if (currentElement == WALL){
                putStringAt(104,0, "Wall ('#')", Color::BrightBlack);
            }
            else if (currentElement == AIR){
                putStringAt(104,0, "Air (' ')", Color::Magenta);
            }
            printBoard(elementArray, HEIGHT, WIDTH);

            if((c == 'w' || c == 'W') && y > 1)
            {
                y--;
            }
            else if((c == 's' || c == 'S') && y < HEIGHT)
            {
                y++;
            }
            else if((c == 'a' || c == 'A') && x > 0)
            {
                x--;
            }
            else if((c == 'd' || c == 'D') && x < WIDTH - 1)
            {
                x++;
            }
            else if(c == '1'){
                if (currentElement != SAND){
                    currentElement = SAND;
                }
            }
            else if(c == '2'){
                if (currentElement != WATER){
                    currentElement = WATER;
                }
            }
            else if(c == '3'){
                if (currentElement != WALL){
                    currentElement = WALL;
                }
            }
            else if(c == '4'){
                if (currentElement != AIR){
                    currentElement = AIR;
                }
            }
            else if(c == ' '){
                if (currentElement == SAND){
                    elementArray [y-1][x] = '*';
                }
                else if (currentElement == WATER){
                    elementArray [y-1][x] = '~';
                }
                else if (currentElement == WALL){
                    elementArray [y-1][x] = '#';

                }
                else if (currentElement == AIR){
                    elementArray [y-1][x] = ' ';

                }
            }
            else if(c == 'q' || c == 'Q'){
                updateBoard(elementArray, HEIGHT, WIDTH);
            }
            else if(c == 'r' || c == 'R'){
                fillBoard(elementArray, HEIGHT, WIDTH);
            }

        }
    }

    return 0;
}
